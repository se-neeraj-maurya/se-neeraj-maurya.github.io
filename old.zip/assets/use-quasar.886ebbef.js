import{h as a,k as e,i as s,aR as r}from"./index.3996516f.js";const t=a("div",{class:"q-space"});var n=e({name:"QSpace",setup(){return()=>t}});function p(){return s(r)}export{n as Q,p as u};
